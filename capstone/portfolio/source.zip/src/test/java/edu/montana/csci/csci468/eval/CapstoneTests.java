package edu.montana.csci.csci468.eval;

import edu.montana.csci.csci468.CatscriptTestBase;
import edu.montana.csci.csci468.parser.ErrorType;
import edu.montana.csci.csci468.parser.statements.VariableStatement;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

public class CapstoneTests extends CatscriptTestBase {

    //Tests that both additive and factor expressions evaluate properly even when used in combination
    @Test
    void Test1() {
        assertEquals(6, evaluateExpression("2 + 8 / 2"));
    }

    //Tests that function arguments work correctly in CatScript
    @Test
    void Test2() {
        assertEquals("1\n", executeProgram("function func(x) { print(x) }\n" +
                "func(1)"));
    }

    //Tests that lists evaluate correctly in CatScript
    @Test
    void Test3() {
        assertEquals(Arrays.asList("a", "b", "c"), evaluateExpression("[\"a\", \"b\", \"c\"]"));
    }

    @Test
    void Test4(){assertEquals("1\n", executeProgram("var x:object = 1\n" + "print(x)"));}

    @Test
    void Test5(){assertEquals("true true true true true\n", compile("for(x in [5]){print(true)}"));}

    @Test
    void Test6() {
        assertEquals("1\n", compile("func()\n" + "function func() { print(1) }"));
    }
    @Test
    void Test7() {
        VariableStatement expr = parseStatement("var x : list<int> = [1, 2, 3]");
//        assertNotNull(expr);
        assertEquals("x", expr.getVariableName());
    }

    @Test
    void Test8() {
        System.out.println(Object.class.isAssignableFrom(String.class));
    }

}
